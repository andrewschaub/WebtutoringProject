Name(s)		   : Shaily Gupta, A00952989
& Student ID	 Andrew Schaub, A00936744

Project Completion:  100% complete
Set Up Instructions: All of the database code is in a directory called db. The name of the file is DDL-and-data.txt. 
					 Use this file to get all the sample data to be used from the database
					 *Please create database called "Tuition"!!

Summary:
We were quite fast to grasp the new concepts, therefore it didn't take us much long to develop the website. The one part that we did struggle on was the shooping cart 'checkout' part. It took us an entire week to get that working. While, all our other stuff was finshed in 2-4 days. Because we had some time left on our hands, we tried to tackle the total part of checkout. We weren't quite successful to accomplish that. Next time we hope to get better understanding of how the total would work and how would it be implemented via our code. 



